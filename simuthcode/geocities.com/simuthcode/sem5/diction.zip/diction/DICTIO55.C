/*          DICTIONARY IMPLEMENTATION
		 BY
		  O.R.SENTHIL KUMARAN  */


#include<stdio.h>
#include<io.h>
#include<conio.h>
FILE *fin,*fout;
struct dic
	{
		char eng[20];
		char tam[20];
	}sno[1000],word;
void main()
{
	int l=0;
	clrscr();
	do
	{
		clrscr();
		printf("\t                  DICTIONARY        \n");
		printf("\t      1.Append\n");
		printf("\t      2.Searching\n");
		printf("\t      3.Display\n");
		printf("\t      4.Exit\n");
		printf("   Enter your choice\n");
		switch(getch())
		{

		case'1':
			fin=fopen("FILEDICTION.DAT","a+");
			append();
			fclose(fin);
			break;
		case'2':
			fout=fopen("FILEDICTION.DAT","r");
			rewind(fout);
			search();
			fclose(fout);
			break;
		case'3':
			fout=fopen("FILEDICTION.DAT","r");
			rewind(fout);
			display();
			fclose(fout);
			break;
		case'4':
			exit(0);
		}
	}while(l==0);
}
search()
{
	int i=0;
	char word1[20];
	clrscr();
	printf("\tEnter your option please\n");
	printf("\t\t  1.Tamil To English\n");
	printf("\t\t  2.English To Tamil\n");
	switch(getch())
	{
	case'2':
		printf("\tGive the English word\n");
		scanf("%s",word1);
		while(fread(word.eng,sizeof(word),1,fout)==1)
		{
			if(strcmp(word1,word.eng)==0)
			{
				printf("\tThe tamil word is\n");
				printf("%s",word.tam);
				getch();
				return;
			}
		}
	 case '1':
		printf("\tGive the Tamil word\n");
		scanf("%s",word1);
		while(fread(word.tam,sizeof(word),1,fout)==1)
		{
			if(strcmp(word1,word.tam)==0)
			{
				printf("\tThe tamil word is\n");
				printf("%s",word.tam);
				getch();
				return;
			}
		}
		getch();
	}
	}
 append()
 {
	int i;
	do
	{
		printf("\tGive the english word\n");
		scanf("%s",sno[i].eng);
		printf("\tGive the tamil word\n");
		scanf("%s",sno[i].tam);
		fwrite(&sno[i],sizeof(sno[i]),1,fin);
		printf("\nContinue y/n\n");
	}while(getch()!='n');
}
display()
{
	clrscr();
	printf("\t      CONTENTS\n");
	while(fread(&word,sizeof(word),1,fout)==1)
	{
		printf("\n\t%s\t\t%s\n",word.eng,word.tam);
	}
	getch();
}
//                       ***END***

