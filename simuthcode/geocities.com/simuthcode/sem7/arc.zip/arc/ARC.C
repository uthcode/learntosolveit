
#include <stdio.h>
#include <conio.h>
#include <graphics.h>
void main()
{
   int gd=DETECT,stang,gm,h,k;
   float r,endang,x,xend,y;
   initgraph(&gd,&gm,"w:\\tc\\bgi");
   printf("enter tbe center  points and radius");
   scanf("%d%d%d",&h,&k,&r);
   printf("enter the start angle and endangle");
   scanf("%d%d",&stang,&endang);
   switch (stang)
   {
   case 90:
	 x=0.0;
	 xend=r;
	 while(x<=xend)
	 {
	 y=sqrt((r*r)+(x*x));
	 putpixel(x+h,y+k,1);
	 x=x+0.5;
	 }
   case 0:
	 x=0.0;
	 xend=r;
	 while(x<=xend)
	 {
	 y=sqrt((r*r)+(x*x));
	 putpixel(x+h,y+k,1);
	 x=x+0.5;
	 }
   case 180:
	 x=0.0;
	 xend=r;
	 while(x<=xend)
	 {
	 y=sqrt((r*r)+(x*x));
	 putpixel(x+h,y+k,6);
	 x+=0.5;
	 }
      }
      getch();
      closegraph();
      }

