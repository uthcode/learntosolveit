#include <stdio.h>
#include <conio.h>


int r0,u0,avail,i,j,k;
int loan[30],max[30],claim[30];
int safe(int k,int i)
{
int j,p;
for(j=0;j<=i;j++)
{
p=claim[j]+k;
if((p<avail)||(max[i]-loan[i]==k))
return 1;
}
return 0;
}


int main()
{
int i,k,flag;
clrscr();
printf("enter the no of resources\n");
scanf("%d",&r0);
printf("enter the no of users\n");
scanf("%d",&u0);
avail=r0;
i=0;
while(i<u0)
{
printf("\n\n enter the max of resources for users",i+1);
scanf("%d",&k);
if(k>r0)
{
printf("total resource avail is %d",r0);
continue;
}
max[i]=k;
i=i+1;
}
for(i=0;i<u0;i++)
claim[i]=0;
i=0;
while(i<u0)
{
printf("enter the no of resource presently needed for user %d",i+1);
scanf("%d",&k);
if((k<max[i])&&(safe(k,i)))
{
loan[i]=k;
printf("resources is allocated to user %d",i+1);
claim[i]=max[i]-loan[i];
avail=avail-k;
}
else
{
printf("\n unsafe state");
continue;
}
i=i+1;
}
flag=0;
for(i=0;i<u0;i++)
{
if (claim[i]<=avail)
flag=1;
}
clrscr();
printf("BANKERS ALGORITHM");
printf("\n\n\n------------------------------------");
printf("\n current loan \t\t\t maximum needed\n");
printf("\n--------------------------------------");

for(i=0;i<u0;i++)
printf("\n user%d         %d            %d ",i+1,loan[i],max[i]);
printf("\n");
printf("\n");
printf("\n\n available resources %d",avail);
if(flag==1)
printf("\nsafe state");
else
printf("\n unsafe state");
getch();
return(0);
}



