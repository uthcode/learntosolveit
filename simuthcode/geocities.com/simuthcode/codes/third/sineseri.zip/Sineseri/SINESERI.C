			    //sum of sine series
#include <conio.h>
#include<stdio.h>
#include<math.h>
void main()
{
 int x,n,i,k=1,sn=1;
 float s=0;
 clrscr();
 printf("enter the value for n:");
 scanf("%d",&n);
 printf("enter the value for x: ");
 scanf("%d",&x);
 for(i=1;i<=n;i+=2)
 {
  s=s+sn*(pow(x,k))/factor(k);
  sn=sn*-1,
 k=k+2;
  }
  printf("sum of sine series:%f",s);
  getch();
}
int factor(j)
int j;
{
 int fact=1,i=1;
 if(j<1)
  {
    printf("if the the value of n is less than 1.try to enter the value for n>=1");
  }
 else
 if(j==1)
 return(fact);
 else
 for(;i<=j;i++)
 fact=fact*i;
 return(fact);
}

