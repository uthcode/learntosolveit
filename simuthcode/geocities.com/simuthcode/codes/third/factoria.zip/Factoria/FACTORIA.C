int main(void)
{
  int n,nsave,factorial;
  clrscr();
  printf("Enter the value for N:");
  scanf("%d",&n);
  nsave=n;
  factorial=1;
  while(n>1)
  {
    factorial*=n;
    n--;
  }
  printf("\t\t%d! = %d\n",nsave,factorial);
  getch();
}
