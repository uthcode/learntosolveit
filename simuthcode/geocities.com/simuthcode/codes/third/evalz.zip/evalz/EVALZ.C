#include"math.h"
int main(void)
{
  int x,y;
  long z;
  clrscr();
  printf("Enter the value of x:\t");
  scanf("%d",&x);
  printf("\nEnter the value of y:\t");
  scanf("%d",&y);
  z=pow(x,2)+pow(y,2);
  printf("The value of the expression Z = x^2+y^2 = %ld",z);
  getch();
 return 0;
}


