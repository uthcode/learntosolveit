	      //program for counting no of words in the given string
#include<stdio.h>
#include<string.h>
#include<conio.h>
void main()
{
 int *p,i,n=0;
 char x[50];
 clrscr();
 printf("Enter the string:");
 scanf("%s",x[i]);
 for(i=0;(x[i]=getchar())!='\n';i++)
 ;
 for(i=0;x[i]!='\0';i++)
 {
 *p=x[i];
 if(*p==(char)32)
 {
 n++;
 }
 }
 printf("The no of words in the given string: %d",n+1);
 getch();
 }