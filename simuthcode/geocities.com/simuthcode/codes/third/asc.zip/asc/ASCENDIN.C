int main(void)
{
 int n,i;
 clrscr();
 printf("\Enter the Number \t");
 scanf("%d",&n);
 for(i=0;i<n;i++)
 printf("%d\n",i+1);
 getch();
}
