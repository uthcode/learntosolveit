               winamp skin Featuring UTHCODE.COM
               ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


           HI Friends
           Though it took 5 Hrs to Engineer this skin
           the result was satisfactory...
           Enjoy the effect.....and pass me the feed back...
           mail me at: giri@uthcode.com


                Instructions for installation
                ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
          WITHOUT UNZIPPING THE FILE, Copy and past it into
          the directory where your winamp skins are placed

          eg: c:\program files\Winamp\skins

          substitute appropriate drive letter


          p.s: Make sure that u have winzip in ur system




              ENJOY...........LIFE......ALL THE BEST........






                 | date: 2/5/2001 | time: 10:38 |