import Grizzly.__main__
if __name__ == "__main__":
    Grizzly.__main__.main()
